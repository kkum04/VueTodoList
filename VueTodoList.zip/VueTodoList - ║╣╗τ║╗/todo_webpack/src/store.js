export const store = {
  todoList: [
    {
      title: "Vue 공부하기",
      isDone: true
    },
    {
      title: "Vue component 사용법",
      isDone: false
    },
    {
      title: "Vue Router 사용법",
      isDone: false
    },
    {
      title: "Vue study 준비",
      isDone: false
    },
    {
      title: "Vue study 준비",
      isDone: false
    }
  ],
  selectedTodo: {}
};
