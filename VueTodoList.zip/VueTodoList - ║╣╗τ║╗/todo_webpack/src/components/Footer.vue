<template lang="jade">
  footer.row.text-center
    span.h3 Copyright.....
</template>

<script>
  export default {
    name: 'footer-component'
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  footer{
    border-top: 1px solid black;
    margin-top:100px;
  }
</style>
