<template lang="jade">
  header.row.text-center
    span.h1 박태환 Todo list
</template>

<script>
  export default {
    name: 'header-component'
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  header{
    border-bottom: 1px solid black;
    margin-bottom: 50px;
  }
</style>
